# Android / Android TV — ImpulsaTV V3

- `minSdk 23`, `targetSdk 36`, `compileSdk 36`.
- AGP 9.4.0 (requiere Gradle 9.6.0 y JDK 17 como mínimo).
- Media3 1.11.1.
- Compose + Compose for TV.

## Prueba en emulador
El valor inicial apunta a `http://10.0.2.2:8000/api/v1/`.

## Prueba en TV Box / teléfono
En la pantalla de login reemplazá el servidor por la IP LAN del equipo donde corre FastAPI, por ejemplo `http://192.168.1.20:8000`.

## Funciones actuales
- Login.
- Perfil principal.
- Home dinámico.
- Continuar viendo.
- Favoritos.
- Ticket de playback.
- ExoPlayer/Media3.
- Guardado de progreso VOD.

El proyecto no incluye un Gradle Wrapper binario dentro del ZIP; Android Studio puede configurar/sincronizar Gradle 9.6.0 para AGP 9.4.0.
