package com.impulsa.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class PlayerActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private var token: String = ""
    private var kind: String = ""
    private var itemId: Int = 0
    private var profileId: Int = 0
    private var apiBase: String = BuildConfig.API_BASE_URL

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra("url") ?: return finish()
        token = intent.getStringExtra("token").orEmpty()
        kind = intent.getStringExtra("kind").orEmpty()
        itemId = intent.getIntExtra("item_id", 0)
        profileId = intent.getIntExtra("profile_id", 0)
        apiBase = intent.getStringExtra("api_base") ?: BuildConfig.API_BASE_URL
        val startMs = intent.getLongExtra("start_ms", 0L)

        player = ExoPlayer.Builder(this).build().also { exo ->
            exo.setMediaItem(MediaItem.fromUri(url))
            exo.prepare()
            if (startMs > 0) exo.seekTo(startMs)
            exo.playWhenReady = true
        }
        setContentView(PlayerView(this).also { view ->
            view.player = player
            view.keepScreenOn = true
        })
    }

    override fun onStop() {
        saveProgress()
        super.onStop()
    }

    private fun saveProgress() {
        val exo = player ?: return
        if (kind != "vod" || itemId <= 0 || token.isBlank()) return
        val position = (exo.currentPosition.coerceAtLeast(0L) / 1000.0)
        val duration = (exo.duration.coerceAtLeast(0L) / 1000.0)
        thread(name = "impulsa-progress", isDaemon = true) {
            runCatching {
                val base = apiBase.removeSuffix("/")
                val connection = URL("$base/me/progress/$itemId").openConnection() as HttpURLConnection
                connection.requestMethod = "PUT"
                connection.connectTimeout = 5000
                connection.readTimeout = 5000
                connection.doOutput = true
                connection.setRequestProperty("Authorization", "Bearer $token")
                connection.setRequestProperty("Content-Type", "application/json")
                val body = JSONObject()
                    .put("position_seconds", position)
                    .put("duration_seconds", duration)
                    .put("profile_id", if (profileId > 0) profileId else JSONObject.NULL)
                connection.outputStream.bufferedWriter().use { it.write(body.toString()) }
                connection.responseCode
                connection.disconnect()
            }
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
