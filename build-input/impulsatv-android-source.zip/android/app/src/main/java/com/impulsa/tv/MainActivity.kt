package com.impulsa.tv

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { ImpulsaApp() } }
    }
}

data class Session(val token: String, val displayName: String, val profileId: Int?)
data class UiItem(
    val id: Int,
    val kind: String,
    val title: String,
    val meta: String,
    val playbackUrl: String?,
    val resumeSeconds: Double = 0.0,
)
data class UiSection(val title: String, val items: List<UiItem>)
data class ResolvedPlayback(val url: String, val kind: String, val id: Int)

object ApiConfig {
    var baseUrl: String = BuildConfig.API_BASE_URL
    fun normalize(value: String): String {
        var v = value.trim().removeSuffix("/")
        if (!v.endsWith("/api/v1")) v += "/api/v1"
        return "$v/"
    }
}

private fun apiUrl(path: String): String {
    if (path.startsWith("http")) return path
    val host = ApiConfig.baseUrl.removeSuffix("/api/v1/").removeSuffix("/")
    return host + if (path.startsWith("/")) path else "/$path"
}

private suspend fun requestJson(
    path: String,
    method: String = "GET",
    body: JSONObject? = null,
    token: String? = null,
): JSONObject = withContext(Dispatchers.IO) {
    val connection = URL(apiUrl(path)).openConnection() as HttpURLConnection
    connection.connectTimeout = 8000
    connection.readTimeout = 10000
    connection.requestMethod = method
    connection.setRequestProperty("Accept", "application/json")
    if (!token.isNullOrBlank()) connection.setRequestProperty("Authorization", "Bearer $token")
    if (body != null) {
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json")
        connection.outputStream.bufferedWriter().use { it.write(body.toString()) }
    }
    try {
        val ok = connection.responseCode in 200..299
        val stream = if (ok) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (!ok) {
            val message = runCatching { JSONObject(text).optString("detail") }.getOrNull().orEmpty()
            error(message.ifBlank { "HTTP ${connection.responseCode}" })
        }
        if (text.isBlank()) JSONObject() else JSONObject(text)
    } finally {
        connection.disconnect()
    }
}

private suspend fun login(email: String, password: String): Pair<String, String> {
    val payload = JSONObject().put("email", email.trim()).put("password", password)
    val auth = requestJson("/api/v1/auth/login", "POST", payload)
    val token = auth.getString("access_token")
    val me = requestJson("/api/v1/auth/me", token = token)
    return token to me.optString("display_name", "Usuario")
}

private suspend fun registerUser(email: String, password: String) {
    val name = email.substringBefore("@").ifBlank { "Usuario" }.take(80)
    val payload = JSONObject().put("email", email.trim()).put("password", password).put("display_name", name)
    requestJson("/api/v1/auth/register", "POST", payload)
}

private suspend fun firstProfileId(token: String): Int? = withContext(Dispatchers.IO) {
    val connection = URL(apiUrl("/api/v1/me/profiles")).openConnection() as HttpURLConnection
    connection.connectTimeout = 8000
    connection.readTimeout = 8000
    connection.requestMethod = "GET"
    connection.setRequestProperty("Authorization", "Bearer $token")
    try {
        if (connection.responseCode !in 200..299) return@withContext null
        val text = connection.inputStream.bufferedReader().use { it.readText() }
        val array = JSONArray(text)
        if (array.length() > 0) array.getJSONObject(0).optInt("id") else null
    } finally {
        connection.disconnect()
    }
}

private suspend fun loadHome(session: Session?): List<UiSection> = withContext(Dispatchers.IO) {
    val path = if (session != null) {
        "/api/v1/me/home" + (session.profileId?.let { "?profile_id=$it" } ?: "")
    } else "/api/v1/home"
    val connection = URL(apiUrl(path)).openConnection() as HttpURLConnection
    connection.connectTimeout = 8000
    connection.readTimeout = 10000
    connection.requestMethod = "GET"
    if (session != null) connection.setRequestProperty("Authorization", "Bearer ${session.token}")
    try {
        if (connection.responseCode !in 200..299) error("HTTP ${connection.responseCode}")
        val root = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
        val sections = root.getJSONArray("sections")
        buildList {
            for (i in 0 until sections.length()) {
                val s = sections.getJSONObject(i)
                val arr = s.getJSONArray("items")
                add(UiSection(s.optString("title", "Sección"), buildList {
                    for (j in 0 until arr.length()) {
                        val x = arr.getJSONObject(j)
                        val meta = when {
                            x.has("current") && !x.isNull("current") -> x.getJSONObject("current").optString("title")
                            x.optString("genre").isNotBlank() -> x.optString("genre")
                            x.optString("group").isNotBlank() -> x.optString("group")
                            else -> x.optString("media_type")
                        }
                        val progress = x.optJSONObject("progress")?.optDouble("position_seconds", 0.0) ?: 0.0
                        add(
                            UiItem(
                                id = x.optInt("id"),
                                kind = x.optString("kind", "media"),
                                title = x.optString("title", "Contenido"),
                                meta = meta,
                                playbackUrl = x.optString("playback_url").ifBlank { null },
                                resumeSeconds = progress,
                            )
                        )
                    }
                }))
            }
        }
    } finally {
        connection.disconnect()
    }
}


private suspend fun addFavorite(item: UiItem, session: Session) {
    val body = JSONObject()
        .put("kind", if (item.kind == "channel") "channel" else "media")
        .put("item_id", item.id)
        .put("profile_id", session.profileId ?: JSONObject.NULL)
    requestJson("/api/v1/me/favorites", "POST", body, session.token)
}

private suspend fun resolvePlayback(path: String, token: String): ResolvedPlayback {
    val ticket = requestJson(path, token = token)
    val source = requestJson(ticket.getString("ticket_url"), token = token)
    return ResolvedPlayback(source.getString("url"), source.optString("kind", "vod"), source.optInt("id"))
}

@Composable
fun ImpulsaApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("impulsa_tv", Context.MODE_PRIVATE) }
    ApiConfig.baseUrl = ApiConfig.normalize(prefs.getString("api_base", BuildConfig.API_BASE_URL) ?: BuildConfig.API_BASE_URL)
    var session by remember {
        mutableStateOf(
            prefs.getString("token", null)?.let {
                Session(it, prefs.getString("name", "Usuario") ?: "Usuario", prefs.getInt("profile_id", 0).takeIf { id -> id > 0 })
            }
        )
    }

    if (session == null) {
        LoginScreen(
            initialServer = ApiConfig.baseUrl,
            onLogin = { s, server ->
                ApiConfig.baseUrl = ApiConfig.normalize(server)
                prefs.edit().putString("api_base", ApiConfig.baseUrl).putString("token", s.token).putString("name", s.displayName).putInt("profile_id", s.profileId ?: 0).apply()
                session = s
            },
        )
    } else {
        HomeScreen(session = session!!, onLogout = {
            prefs.edit().clear().apply()
            session = null
        })
    }
}

@Composable
private fun LoginScreen(initialServer: String, onLogin: (Session, String) -> Unit) {
    var server by remember { mutableStateOf(initialServer) }
    var email by remember { mutableStateOf("demo@impulsa.local") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Box(Modifier.fillMaxSize().background(Color(0xFF07090D)).padding(56.dp)) {
        Column(Modifier.width(520.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("IMPULSA TV", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Bold)
            Text("Inicia sesión para reproducir y continuar donde quedaste.", color = Color(0xFFADB8CA), fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = server, onValueChange = { server = it }, label = { Text("Servidor (ej. http://192.168.1.20:8000)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Correo") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Contraseña") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            error?.let { Text(it, color = Color(0xFFFF8A80)) }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(enabled = !busy, onClick = {
                    busy = true; error = null
                    scope.launch {
                        runCatching {
                            ApiConfig.baseUrl = ApiConfig.normalize(server)
                            val (token, name) = login(email, password)
                            Session(token, name, firstProfileId(token))
                        }.onSuccess { onLogin(it, server) }.onFailure { error = it.message ?: "No se pudo iniciar sesión" }
                        busy = false
                    }
                }) { Text(if (busy) "Ingresando…" else "Ingresar") }
                Button(enabled = !busy, onClick = {
                    busy = true; error = null
                    scope.launch {
                        runCatching {
                            ApiConfig.baseUrl = ApiConfig.normalize(server)
                            registerUser(email, password)
                            val (token, name) = login(email, password)
                            Session(token, name, firstProfileId(token))
                        }.onSuccess { onLogin(it, server) }.onFailure { error = it.message ?: "No se pudo crear la cuenta" }
                        busy = false
                    }
                }) { Text("Crear cuenta") }
            }
        }
    }
}

@Composable
private fun HomeScreen(session: Session, onLogout: () -> Unit) {
    var sections by remember { mutableStateOf<List<UiSection>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(session.token, session.profileId) {
        runCatching { loadHome(session) }.onSuccess { sections = it }.onFailure { error = it.message ?: "No se pudo cargar el catálogo" }
    }
    Column(Modifier.fillMaxSize().background(Color(0xFF07090D)).padding(34.dp), verticalArrangement = Arrangement.spacedBy(22.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column { Text("IMPULSA TV", color = Color.White, fontSize = 31.sp, fontWeight = FontWeight.Bold); Text(session.displayName, color = Color(0xFFAAB6C8), fontSize = 15.sp) }
            Button(onClick = onLogout) { Text("Salir") }
        }
        error?.let { Text("Backend: $it", color = Color(0xFFFF8A80), fontSize = 17.sp) }
        if (sections.isEmpty() && error == null) Text("Cargando catálogo…", color = Color.LightGray, fontSize = 18.sp)
        sections.forEach { section ->
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(section.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(section.items, key = { "${section.title}-${it.kind}-${it.id}" }) { MediaCard(it, session) }
                }
            }
        }
    }
}

@Composable
private fun MediaCard(item: UiItem, session: Session) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var favoriteSaved by remember { mutableStateOf(false) }
    var focused by remember { mutableStateOf(false) }
    val borderColor = if (focused) Color(0xFF8EA0FF) else Color(0xFF2B3445)
    Box(
        Modifier.width(235.dp).height(132.dp)
            .border(if (focused) 3.dp else 1.dp, borderColor, RoundedCornerShape(14.dp))
            .background(if (focused) Color(0xFF27304A) else Color(0xFF171C26), RoundedCornerShape(14.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(enabled = item.playbackUrl != null && !busy) {
                val path = item.playbackUrl ?: return@clickable
                busy = true
                scope.launch {
                    runCatching { resolvePlayback(path, session.token) }
                        .onSuccess { source ->
                            context.startActivity(
                                Intent(context, PlayerActivity::class.java)
                                    .putExtra("url", source.url)
                                    .putExtra("kind", source.kind)
                                    .putExtra("item_id", source.id)
                                    .putExtra("token", session.token)
                                    .putExtra("profile_id", session.profileId ?: 0)
                                    .putExtra("start_ms", (item.resumeSeconds * 1000).toLong())
                                    .putExtra("title", item.title)
                                    .putExtra("api_base", ApiConfig.baseUrl)
                            )
                        }
                    busy = false
                }
            }.focusable().padding(17.dp)
    ) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Bottom) {
            Text(if (busy) "Abriendo…" else item.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
            if (item.meta.isNotBlank()) Text(item.meta, color = Color(0xFFAEB8C8), fontSize = 13.sp, maxLines = 1)
            if (item.resumeSeconds > 0) Text("Continuar desde ${item.resumeSeconds.toInt() / 60} min", color = Color(0xFF91A5FF), fontSize = 12.sp)
            Text(
                if (favoriteSaved) "★ Guardado" else "☆ Favorito",
                color = if (favoriteSaved) Color(0xFFFFD76B) else Color(0xFFBFC8D8),
                fontSize = 12.sp,
                modifier = Modifier.clickable {
                    scope.launch {
                        runCatching { addFavorite(item, session) }.onSuccess { favoriteSaved = true }
                    }
                }.padding(top = 4.dp)
            )
        }
    }
}
